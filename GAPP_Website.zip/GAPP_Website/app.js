require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
const expressLayouts = require('express-ejs-layouts');
const { Pool } = require('pg');

// Routers
const authRoutes = require('./routes/auth');
const facultyRoutes = require('./routes/faculty');
const adminRoutes = require('./routes/admin');
const superRoutes = require('./routes/super');
const apiRoutes = require('./routes/api');

const app = express();

// Mongo
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('Mongo error:', err));

// Postgres (audit)
const pool = new Pool({
  host: process.env.PGHOST,
  port: +process.env.PGPORT,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE
});
pool.query(`
CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  at TIMESTAMP DEFAULT NOW(),
  actor_email TEXT,
  action TEXT,
  payload JSONB
);
`).catch(console.error);

// expose audit logger
app.use((req, res, next) => {
  req.audit = async (action, payload = {}) => {
    const actor = req.session?.user?.email || 'anonymous';
    await pool.query('INSERT INTO audit_logs(actor_email, action, payload) VALUES ($1,$2,$3);',
      [actor, action, payload]);
  };
  next();
});

// views
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);
app.set('layout', 'layouts/main');

// static & parsers
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

// session
app.use(session({
  secret: process.env.SESSION_SECRET || 'gapp-secret',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
  cookie: { maxAge: 1000 * 60 * 60 * 6 } // 6 hours
}));

// expose session to templates
app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});

// routes
app.use('/', authRoutes);
app.use('/faculty', facultyRoutes);
app.use('/admin', adminRoutes);
app.use('/super', superRoutes);
app.use('/api', apiRoutes);

// start
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`GAPP running http://localhost:${PORT}`));
