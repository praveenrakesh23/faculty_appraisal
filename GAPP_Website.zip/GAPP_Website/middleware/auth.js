module.exports = function requireAuth(roles /* array|string|undefined */) {
  return (req, res, next) => {
    if (!req.session || !req.session.user) return res.redirect('/login');
    if (roles) {
      const allowed = Array.isArray(roles) ? roles : [roles];
      if (!allowed.includes(req.session.user.role)) return res.status(403).send('Forbidden');
    }
    next();
  };
};
