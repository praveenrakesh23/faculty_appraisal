require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Settings = require('./models/Settings');

async function run(){
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Seeding…');

  const mk = async (role, email, pass, name, department) => {
    const has = await User.findOne({ email });
    if (has) return console.log('exists:', email);
    const hashed = await bcrypt.hash(pass, 10);
    await User.create({ role, email, password: hashed, name, department });
    console.log('created:', role, email, '/', pass);
  };

  await mk('admin', process.env.SEED_ADMIN_EMAIL || 'admin@college.edu', process.env.SEED_ADMIN_PASS || 'admin123', 'College Admin', 'Admin');
  await mk('superadmin', process.env.SEED_SUPER_EMAIL || 'super@gapp.io', process.env.SEED_SUPER_PASS || 'super123', 'Super Admin', 'HQ');
  await mk('faculty', process.env.SEED_FAC_EMAIL || 'faculty@college.edu', process.env.SEED_FAC_PASS || 'faculty123', 'Seed Faculty', 'CSE');

  const hasSettings = await Settings.findOne();
  if (!hasSettings) {
    await Settings.create({ weights:{ teaching:40, research:30, activities:30 }, cycle:{ name:'Annual' } });
    console.log('settings created');
  }

  process.exit(0);
}
run().catch(e => { console.error(e); process.exit(1); });
