const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Settings = require('../models/Settings');
const requireAuth = require('../middleware/auth');

const router = express.Router();

// Super Admin (Maintainer) dashboard: manage users + weights + cycles
router.get('/dashboard', requireAuth('superadmin'), async (req, res) => {
  const users = await User.find().select('name email role department').lean();
  const settings = await Settings.findOne().lean() || { weights:{teaching:40,research:30,activities:30}, cycle:{name:'Annual'} };
  res.render('superDashboard', { users, settings });
});

router.post('/user', requireAuth('superadmin'), async (req, res) => {
  const { name, email, password, role, department } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  const doc = await User.create({ name, email, password: hashed, role, department: department || 'General' });
  await req.audit('super.user.create', { email, role });
  res.redirect('/super/dashboard');
});

router.post('/settings', requireAuth('superadmin'), async (req, res) => {
  const weights = {
    teaching: Number(req.body.teaching) || 40,
    research: Number(req.body.research) || 30,
    activities: Number(req.body.activities) || 30
  };
  const cycle = {
    name: req.body.cycleName || 'Annual',
    startDate: req.body.startDate || '',
    endDate: req.body.endDate || ''
  };
  await Settings.findOneAndUpdate({}, { $set: { weights, cycle } }, { upsert: true });
  await req.audit('super.settings.update', { weights, cycle });
  res.redirect('/super/dashboard');
});

module.exports = router;
