const express = require('express');
const { createObjectCsvWriter } = require('csv-writer');
const path = require('path');
const fs = require('fs');
const User = require('../models/User');
const requireAuth = require('../middleware/auth');

const router = express.Router();

// faculties JSON (admin)
router.get('/faculties', requireAuth(['admin','superadmin']), async (req, res) => {
  const department = req.query.department;
  const query = { role: 'faculty' };
  if (department) query.department = department;
  const faculties = await User.find(query).select('name email department achievements publications growthProgress').lean();
  res.json({ faculties });
});

// export CSV
router.get('/export/faculties.csv', requireAuth(['admin','superadmin']), async (req, res) => {
  const facs = await User.find({ role: 'faculty' }).select('name email department achievements publications').lean();
  const rows = facs.map(f => ({
    name: f.name || '',
    email: f.email,
    department: f.department || '',
    achievements: (f.achievements || []).length,
    publications: (f.publications || []).length
  }));
  const file = path.join(__dirname, '..', 'public', 'uploads', 'faculties.csv');
  const csvWriter = createObjectCsvWriter({ path: file, header: [
    { id:'name', title:'Name' },{ id:'email', title:'Email' },{ id:'department', title:'Department' },
    { id:'achievements', title:'Achievements' },{ id:'publications', title:'Publications' }
  ]});
  await csvWriter.writeRecords(rows);
  return res.download(file, 'faculties.csv', () => fs.unlink(file, () => {}));
});

module.exports = router;
