const express = require('express');
const path = require('path');
const multer = require('multer');
const User = require('../models/User');
const requireAuth = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, path.join(__dirname, '..', 'public', 'uploads')),
  filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// dashboard
router.get('/dashboard', requireAuth('faculty'), async (req, res) => {
  const faculty = await User.findById(req.session.user.id).lean();
  res.render('facultyDashboard', { faculty });
});

// personal
router.post('/personal', requireAuth('faculty'), upload.single('resume'), async (req, res) => {
  const updates = {
    'personal.dob': req.body.dob || '',
    'personal.phone': req.body.phone || '',
    'personal.address': req.body.address || ''
  };
  if (req.file) updates['personal.resume'] = { name: req.file.originalname, path: '/uploads/' + req.file.filename };
  await User.findByIdAndUpdate(req.session.user.id, { $set: updates });
  await req.audit('faculty.personal.update', updates);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true });
  res.redirect('/faculty/dashboard');
});

// achievements
router.post('/achievement', requireAuth('faculty'), upload.single('proof'), async (req, res) => {
  const item = {
    title: req.body.title || 'Untitled',
    year: Number(req.body.year) || new Date().getFullYear(),
    proof: req.file ? { name: req.file.originalname, path: '/uploads/' + req.file.filename } : null
  };
  await User.findByIdAndUpdate(req.session.user.id, { $push: { achievements: item } });
  await req.audit('faculty.achievement.add', item);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true, item });
  res.redirect('/faculty/dashboard');
});

// awards
router.post('/award', requireAuth('faculty'), upload.single('proof'), async (req, res) => {
  const item = {
    title: req.body.title || 'Untitled Award',
    year: Number(req.body.year) || new Date().getFullYear(),
    proof: req.file ? { name: req.file.originalname, path: '/uploads/' + req.file.filename } : null
  };
  await User.findByIdAndUpdate(req.session.user.id, { $push: { awards: item } });
  await req.audit('faculty.award.add', item);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true, item });
  res.redirect('/faculty/dashboard');
});

// publications
router.post('/publication', requireAuth('faculty'), async (req, res) => {
  const item = {
    title: req.body.title || 'Untitled',
    venue: req.body.venue || '',
    year: Number(req.body.year) || new Date().getFullYear(),
    link: req.body.link || ''
  };
  await User.findByIdAndUpdate(req.session.user.id, { $push: { publications: item } });
  await req.audit('faculty.publication.add', item);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true, item });
  res.redirect('/faculty/dashboard');
});

// experience
router.post('/experience', requireAuth('faculty'), async (req, res) => {
  const item = {
    org: req.body.org || '',
    role: req.body.role || '',
    start: req.body.start || '',
    end: req.body.end || '',
    details: req.body.details || ''
  };
  await User.findByIdAndUpdate(req.session.user.id, { $push: { experience: item } });
  await req.audit('faculty.experience.add', item);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true, item });
  res.redirect('/faculty/dashboard');
});

// events
router.post('/event', requireAuth('faculty'), upload.single('certificate'), async (req, res) => {
  const item = {
    title: req.body.title || '',
    role: req.body.role || '',
    date: req.body.date || '',
    certificate: req.file ? { name: req.file.originalname, path: '/uploads/' + req.file.filename } : null
  };
  await User.findByIdAndUpdate(req.session.user.id, { $push: { events: item } });
  await req.audit('faculty.event.add', item);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true, item });
  res.redirect('/faculty/dashboard');
});

// timetable
router.post('/timetable', requireAuth('faculty'), async (req, res) => {
  const entry = { day: req.body.day, hours: Number(req.body.hours) || 0 };
  await User.findByIdAndUpdate(req.session.user.id, { $push: { timetable: entry } });
  await req.audit('faculty.timetable.add', entry);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true, item: entry });
  res.redirect('/faculty/dashboard');
});

// growth
router.post('/growth', requireAuth('faculty'), async (req, res) => {
  const entry = { date: req.body.date || new Date().toISOString().slice(0,10), score: Number(req.body.score) || 0 };
  await User.findByIdAndUpdate(req.session.user.id, { $push: { growthProgress: entry } });
  await req.audit('faculty.growth.add', entry);
  if (req.headers.accept?.includes('application/json')) return res.json({ ok: true, item: entry });
  res.redirect('/faculty/dashboard');
});

module.exports = router;
