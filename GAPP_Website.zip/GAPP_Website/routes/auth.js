const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

const router = express.Router();

router.get('/', (req, res) => {
  if (req.session.user) {
    if (req.session.user.role === 'faculty') return res.redirect('/faculty/dashboard');
    if (['admin','superadmin'].includes(req.session.user.role)) return res.redirect('/admin/dashboard');
  }
  res.render('login', { error: null });
});

router.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/');
  res.render('login', { error: null });
});

router.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.render('login', { error: 'Invalid email or password' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.render('login', { error: 'Invalid email or password' });
    if (role && role !== user.role) return res.render('login', { error: 'Role mismatch' });

    req.session.user = {
      id: user._id, name: user.name || user.email, email: user.email, role: user.role, department: user.department
    };
    if (user.role === 'faculty') return res.redirect('/faculty/dashboard');
    res.redirect('/admin/dashboard');
  } catch (e) {
    console.error(e);
    res.render('login', { error: 'Server error' });
  }
});

router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

module.exports = router;
