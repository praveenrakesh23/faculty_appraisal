const express = require('express');
const User = require('../models/User');
const requireAuth = require('../middleware/auth');

const router = express.Router();

// Admin & Superadmin dashboard
router.get('/dashboard', requireAuth(['admin','superadmin']), async (req, res) => {
  const department = req.query.department || 'All';
  const query = { role: 'faculty' };
  if (department !== 'All') query.department = department;

  const faculties = await User.find(query).lean();
  const departments = await User.distinct('department', { role: 'faculty' });

  const totalFac = faculties.length;
  const totalAch = faculties.reduce((s, f) => s + (f.achievements?.length || 0), 0);
  const totalPubs = faculties.reduce((s, f) => s + (f.publications?.length || 0), 0);
  const avgGrowth = (() => {
    let c = 0, sum = 0;
    faculties.forEach(f => (f.growthProgress || []).forEach(g => { sum += Number(g.score) || 0; c += 1; }));
    return c ? Math.round(sum / c) : 0;
  })();

  res.render('adminDashboard', {
    faculties, departments, selectedDept: department,
    metrics: { totalFac, totalAch, totalPubs, avgGrowth }
  });
});

// Per-faculty deep view
router.get('/faculty/:id', requireAuth(['admin','superadmin']), async (req, res) => {
  const f = await User.findById(req.params.id).lean();
  if (!f) return res.status(404).send('Not found');
  res.render('facultyDetail', { faculty: f });
});

module.exports = router;
