const mongoose = require('mongoose');

const FileRefSchema = new mongoose.Schema({
  name: String,
  path: String,
  uploadedAt: { type: Date, default: Date.now }
}, { _id: false });

const ExperienceSchema = new mongoose.Schema({
  org: String,
  role: String,
  start: String,
  end: String,
  details: String
}, { _id: false });

const PublicationSchema = new mongoose.Schema({
  title: String,
  venue: String,
  year: Number,
  link: String
}, { _id: false });

const EventSchema = new mongoose.Schema({
  title: String,
  role: String,
  date: String,
  certificate: FileRefSchema
}, { _id: false });

const UserSchema = new mongoose.Schema({
  role: { type: String, enum: ['faculty', 'admin', 'superadmin'], required: true },
  department: { type: String, default: 'General' },
  name: { type: String, default: '' },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },

  personal: {
    dob: String,
    phone: String,
    address: String,
    resume: FileRefSchema
  },
  achievements: [{ title: String, year: Number, proof: FileRefSchema }],
  awards: [{ title: String, year: Number, proof: FileRefSchema }],
  publications: [PublicationSchema],
  experience: [ExperienceSchema],
  events: [EventSchema],
  timetable: [{ day: String, hours: Number }],
  growthProgress: [{ date: String, score: Number }]
}, { timestamps: true });

module.exports = mongoose.model('User', UserSchema);
