const mongoose = require('mongoose');

const SettingsSchema = new mongoose.Schema({
  weights: {
    teaching: { type: Number, default: 40 },
    research: { type: Number, default: 30 },
    activities: { type: Number, default: 30 }
  },
  cycle: {
    name: { type: String, default: 'Annual' },
    startDate: String,
    endDate: String
  }
}, { timestamps: true });

module.exports = mongoose.model('Settings', SettingsSchema);
