// Splash (first thing on landing)
(function(){
  const splash = document.getElementById('splash');
  if (!splash) return;
  const enter = document.getElementById('splashEnter');
  const closeSplash = () => { splash.style.opacity = '0'; setTimeout(()=>splash.remove(), 350); };
  enter.addEventListener('click', closeSplash);
  setTimeout(closeSplash, 2400);
})();
