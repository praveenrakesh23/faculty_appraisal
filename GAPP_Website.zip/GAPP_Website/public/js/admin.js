// Admin dashboard interactivity
document.addEventListener('DOMContentLoaded', () => {
  const dept = document.getElementById('deptFilter');
  const searchBox = document.getElementById('searchBox');
  const refreshBtn = document.getElementById('refreshBtn');
  const tableBody = document.querySelector('#facTable tbody');
  const chartCtx = document.getElementById('adminGrowthChart');

  let CHART;

  function renderTable(faculties) {
    tableBody.innerHTML = '';
    const term = (searchBox.value || '').toLowerCase();
    faculties.filter(f => {
      const s = (f.name||'') + ' ' + (f.email||'');
      return s.toLowerCase().includes(term);
    }).forEach(f => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${f.name||'-'}</td><td>${f.email}</td><td>${f.department||'General'}</td><td>${(f.achievements||[]).length}</td><td>${(f.publications||[]).length}</td><td><a class="btn-outline" href="/admin/faculty/${f._id}">Open</a></td>`;
      tableBody.appendChild(tr);
    });
  }

  function renderChart(faculties) {
    const labels = faculties.map(f => f.name || f.email);
    const avgs = faculties.map(f => {
      const arr = f.growthProgress || [];
      if (!arr.length) return 0;
      const sum = arr.reduce((s, g) => s + (+g.score||0), 0);
      return Math.round(sum / arr.length);
    });
    if (CHART) CHART.destroy();
    CHART = new Chart(chartCtx, { type:'bar', data:{ labels, datasets:[{label:'Avg Growth', data: avgs}]}, options:{responsive:true} });
  }

  async function load() {
    const q = dept ? `?department=${encodeURIComponent(dept.value)}` : '';
    const res = await fetch('/api/faculties' + q);
    const { faculties } = await res.json();
    renderTable(faculties);
    renderChart(faculties);
  }

  if (dept) dept.addEventListener('change', () => {
    const value = dept.value;
    const url = new URL(window.location.href);
    url.searchParams.set('department', value);
    window.location.href = url.toString(); // server renders metrics for accuracy
  });
  if (searchBox) searchBox.addEventListener('input', load);
  if (refreshBtn) refreshBtn.addEventListener('click', load);

  // initial client refresh after first render
  setTimeout(load, 200);
});
