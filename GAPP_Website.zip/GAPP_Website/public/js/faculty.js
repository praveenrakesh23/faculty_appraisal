document.addEventListener('DOMContentLoaded', () => {
  const faculty = window.__FACULTY__ || {};

  // Growth chart
  const ctx = document.getElementById('growthChart');
  const initLabels = (faculty.growthProgress || []).map(g => g.date);
  const initScores = (faculty.growthProgress || []).map(g => g.score);
  const growthChart = new Chart(ctx, {
    type: 'line',
    data: { labels: initLabels, datasets: [{ label: 'Growth Score', data: initScores, tension: .35, fill: true }] },
    options: { responsive: true }
  });

  async function ajaxForm(form, url, useFormData = false) {
    const payload = useFormData ? new FormData(form) : new URLSearchParams(new FormData(form));
    const res = await fetch(url, { method: 'POST', body: payload, headers: { 'accept': 'application/json' } });
    return res.json();
  }

  // Personal
  const personalForm = document.getElementById('personalForm');
  if (personalForm) personalForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(personalForm, '/faculty/personal', true);
    if (json.ok) alert('Profile updated');
  });

  // Achievement
  const achForm = document.getElementById('achForm');
  if (achForm) achForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(achForm, '/faculty/achievement', true);
    if (json.ok) {
      const ul = document.getElementById('achList');
      const li = document.createElement('li');
      li.innerHTML = `<strong>${json.item.title}</strong> (${json.item.year})${json.item.proof?.path ? ' — <a target="_blank" href="'+json.item.proof.path+'">proof</a>' : ''}`;
      ul.prepend(li);
      document.getElementById('achCount').textContent = String(+document.getElementById('achCount').textContent + 1);
      achForm.reset();
    }
  });

  // Award
  const awdForm = document.getElementById('awdForm');
  if (awdForm) awdForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(awdForm, '/faculty/award', true);
    if (json.ok) {
      const ul = document.getElementById('awdList');
      const li = document.createElement('li');
      li.innerHTML = `<strong>${json.item.title}</strong> (${json.item.year})${json.item.proof?.path ? ' — <a target="_blank" href="'+json.item.proof.path+'">proof</a>' : ''}`;
      ul.prepend(li);
      document.getElementById('awdCount').textContent = String(+document.getElementById('awdCount').textContent + 1);
      awdForm.reset();
    }
  });

  // Publication
  const pubForm = document.getElementById('pubForm');
  if (pubForm) pubForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(pubForm, '/faculty/publication');
    if (json.ok) {
      const ul = document.getElementById('pubList');
      const li = document.createElement('li');
      li.innerHTML = `<strong>${json.item.title}</strong> — ${json.item.venue} (${json.item.year}) ${json.item.link?'— <a target="_blank" href="'+json.item.link+'">link</a>':''}`;
      ul.prepend(li);
      document.getElementById('pubCount').textContent = String(+document.getElementById('pubCount').textContent + 1);
      pubForm.reset();
    }
  });

  // Experience
  const expForm = document.getElementById('expForm');
  if (expForm) expForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(expForm, '/faculty/experience');
    if (json.ok) { alert('Experience added'); expForm.reset(); }
  });

  // Event
  const evtForm = document.getElementById('evtForm');
  if (evtForm) evtForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(evtForm, '/faculty/event', true);
    if (json.ok) {
      const ul = document.getElementById('evtList');
      const li = document.createElement('li');
      li.innerHTML = `<strong>${json.item.title}</strong> — ${json.item.role} (${json.item.date})${json.item.certificate?.path?' — <a target="_blank" href="'+json.item.certificate.path+'">certificate</a>':''}`;
      ul.prepend(li);
      evtForm.reset();
    }
  });

  // Timetable
  const ttForm = document.getElementById('ttForm');
  if (ttForm) ttForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(ttForm, '/faculty/timetable');
    if (json.ok) location.reload(); // recompute avg hours quickly
  });

  // Growth
  const growthForm = document.getElementById('growthForm');
  if (growthForm) growthForm.addEventListener('submit', async e => {
    e.preventDefault();
    const json = await ajaxForm(growthForm, '/faculty/growth');
    if (json.ok) {
      growthChart.data.labels.push(json.item.date);
      growthChart.data.datasets[0].data.push(json.item.score);
      growthChart.update();
      growthForm.reset();
    }
  });
});
