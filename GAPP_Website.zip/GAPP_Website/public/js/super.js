// Placeholder for future live settings; forms submit server-side already.
// Could add AJAX save + toast here if needed.
